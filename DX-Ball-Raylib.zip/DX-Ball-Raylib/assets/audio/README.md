# Audio Assets

These `.wav` files are **original, synthesized placeholders** (simple sine /
square / triangle oscillator loops), generated from scratch just so the
dual-music-mode system has something audible the moment you clone the repo.
None of them are copies of, or derived from, any existing recording.

They are **not** the songs referenced in the project brief. Actual commercial
recordings (Hans Zimmer, Ludovico Einaudi, Two Steps From Hell, Miles, LRB,
etc.) are copyrighted and can't be redistributed here — you'll need to add
your own legally-owned copies before a public demo/presentation, and you
should **not** commit them to a public GitHub repo (see the root
`.gitignore`, which already excludes real `.mp3`/`.wav` drop-ins under a
`licensed/` folder if you choose to use one — or just keep them local only).

## File → role mapping

| File | Used for | Mood target from the brief |
| --- | --- | --- |
| `bgm_classical_menu.wav` | Main Menu / Pause (Professional mode) | Calm, sophisticated — *Interstellar (Main Theme)* |
| `bgm_classical_gameplay.wav` | Gameplay (Professional mode) | Focused, steady pace — *Experience* |
| `bgm_classical_victory.wav` | Level Clear / Victory (Professional mode) | Epic, polished — *Victory* |
| `bgm_bangla_gameplay.wav` | Gameplay (Bangla Fun mode) | Fast, energetic — *Hasnahana* |
| `bgm_bangla_menu.wav` | Menu / Pause (Bangla Fun mode) | Melodic, nostalgic — *Shei Tumi* |
| `bgm_bangla_gameover.wav` | Game Over (Bangla Fun mode) | Comic timing — *Nissho Korecho Amay* |
| `sfx_paddle.wav` | Paddle bounce | — |
| `sfx_brick.wav` | Brick hit/break | — |
| `sfx_powerup.wav` | Power-up collected | — |
| `sfx_life_lost.wav` | Ball lost | — |

## Swapping in your own tracks

1. Get your own legally-obtained audio (purchased, licensed, or royalty-free
   library music with a similar feel).
2. Convert to `.wav`, `.mp3`, `.ogg`, or `.flac` (raylib supports all four).
3. Overwrite the matching file above, or update the filenames in the
   `LoadMusicStream(...)` calls near the top of `main()` in `dxball.c`.
4. Keep clip lengths reasonable — the loops here are short (a few seconds)
   since `Music.looping = true` handles the repeat in-engine.
